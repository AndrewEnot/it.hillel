package ua.hillel.school.hw4;

public class Transform {

    byte byteNumber;
    short shortNumber;
    int intNumber;
    long longNumber;
    double doubleNumber;
    float floatNumber;
    char charSymbol;

}
