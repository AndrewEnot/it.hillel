package ua.hillel.school.hw16;

public class MoneyValueException extends RuntimeException {


}
