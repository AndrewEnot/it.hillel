package ua.hillel.school.hw8.ex1.logistic;

public class Service {

    int code;             //внутрішній код послуги
    String name;          //назва послуги
    String zone;          //зона перевезень (регіональні, національні, міжнародні)
    double price;         //ціна за кілометр

}
