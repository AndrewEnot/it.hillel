package ua.hillel.school.hw8.ex1.logistic;

public class Warehouse {

    int registerNumWare;      //реєстраційний номер склада (внутрішній)
    String country;           //країна знаходження
    String region;            //регіон_область знаходження
    String city;              //місто знаходження складу
    String address;           //адреса складу
    String owner;             //компанія власник складу
    String name;              //назва складу
    double spaceTotal;        //загальна кількість місць під вантаж
    double spaceFree;         //вільна кількість місць під вантаж
    double costPickup;        //вартість завантаження та супутніх послуг
    double costParking;       //вартість простою_паркування

}
