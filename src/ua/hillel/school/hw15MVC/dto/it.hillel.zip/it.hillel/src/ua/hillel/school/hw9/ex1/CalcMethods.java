package ua.hillel.school.hw9.ex1;

public class CalcMethods {

    static int Add(int a, int b){
        return a + b;
    }
    static double Add(double a, double b) {
        return a + b;
    }
    static int Sub(int a, int b){
        return a - b;
    }
    static double Sub(double a, double b){
        return a - b;
    }
    static int Mul(int a, int b){
            return a * b;
    }
    static double Mul(double a, double b){
            return a * b;
    }
    static int Div (int a, int b) {
            return  a / b;
    }
    static double Div (double a, double b) {
            return  a / b;
    }
}
