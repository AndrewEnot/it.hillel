package ua.exercism.ex9;

class BirdWatcher {
    private final int[] birdsPerDay;

    public BirdWatcher(int[] birdsPerDay) {
        this.birdsPerDay = birdsPerDay.clone();
    }

    public int[] getLastWeek() {
        int[] birdsPerLastWeek = new int[7];
        int j = 0;
        for (int i = birdsPerDay.length-7; i < birdsPerDay.length; i++) {
            birdsPerLastWeek[j] = birdsPerDay[i];
            j += 1;
        }
        return birdsPerLastWeek;
    }

    public int getToday() {
        return birdsPerDay[birdsPerDay.length-1];
    }

    public void incrementTodaysCount() {
        birdsPerDay[birdsPerDay.length-1] += 1;
    }

    public boolean hasDayWithoutBirds() {
        boolean j = false;
        for (int k : birdsPerDay) {
            if (k == 0) {
                j = true;
                break;
            }
        }
        return j;
    }

    public int getCountForFirstDays(int numberOfDays) {
        int[] firstDayCount = new int[numberOfDays];
        int sum = 0;
        for (int i = 0; i < numberOfDays; i++) {
            sum += birdsPerDay[i];
        }
        return sum;
    }

    public int getBusyDays() {
        int busyDays = 0;
        for (int j : birdsPerDay) {
            if (j >= 5) {
                busyDays += 1;
            }
        }
        return busyDays;
    }
}
