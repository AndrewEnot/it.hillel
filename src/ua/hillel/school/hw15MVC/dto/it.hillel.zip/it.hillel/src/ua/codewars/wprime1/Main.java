package ua.codewars.wprime1;

public class Main {

    public static void main(String[] args) {
        System.out.println(WilsonPrime.am_i_wilson(261));
    }
}
