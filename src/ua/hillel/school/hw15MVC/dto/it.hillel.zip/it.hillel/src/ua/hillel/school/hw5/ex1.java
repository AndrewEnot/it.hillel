package ua.hillel.school.hw5;

public class ex1 {

    public static void main(String[] args) {

        for (int i = 0; i < 101; i++) {

            if (i != 16) {

                if (i == 33) {
                    continue;
                }
                System.out.println(i);
            }
        }
    }
}
