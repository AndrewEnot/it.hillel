package ua.hillel.school.hw8.ex1.parking;

public class Ticket {

    int number;       //номер паркувального талону
    int sum;          //сума паркувального талону
    int experience;   //строк використання (в днях)

}
