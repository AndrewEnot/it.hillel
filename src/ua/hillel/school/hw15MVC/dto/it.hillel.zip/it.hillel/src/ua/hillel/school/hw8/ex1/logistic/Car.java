package ua.hillel.school.hw8.ex1.logistic;

public class Car {

    String carNumber;           //державний реєстраційний номер транспорту
    String brand;               //бренд авто
    String model;               //модель авто
    String typeTransport;       //тип авто (тягач, напівпричіп, автопоїзд, вантажне авто..)
    double maxCapacity;         //максимальне навантаження
    double minCapacity;         //мінімальне навантаження
    int numPlaces;              //кількцсть місця під вантаж (м2)
    int cruiseRange;            //запас ходу
    double avFuelConsumption;   //середня витрата палива
    int kmToMaintenance;        //час до технічного обсулговування (в км)
    String specEquipment;       //наявність спецільного обладнання (навантажувач, тощо)

}
