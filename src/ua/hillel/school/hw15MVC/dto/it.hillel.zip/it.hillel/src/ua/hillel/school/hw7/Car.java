package ua.hillel.school.hw7;

public class Car {

    String brandCar;
    String modelCar;
    double priceCar;
    int yearCar;
    int amountCar;

}
