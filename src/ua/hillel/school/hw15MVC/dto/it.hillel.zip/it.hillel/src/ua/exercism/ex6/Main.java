package ua.exercism.ex6;

public class Main {

    public static void main(String[] args) {

        Twofer twofer = new Twofer();
        System.out.println(twofer.twofer("Alice"));
    }
}
