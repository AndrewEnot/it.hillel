package ua.hillel.school.hw16;

public class AccountException extends RuntimeException {


}
