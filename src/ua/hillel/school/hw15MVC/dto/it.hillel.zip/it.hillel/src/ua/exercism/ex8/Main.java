package ua.exercism.ex8;

public class Main {
    public static void main(String[] args) {
        MicroBlog microBlog = new MicroBlog();
        System.out.println(microBlog.truncate("❄🌡🤧🤒🏥🕰😀"));
    }
}
