package ua.hillel.school.hw8.ex1.logistic;

public class Cargo {

    int code;           //внутрішній код вантажу
    String type;        //вид вантажу (галузеве призначення: будівельні матеріали, побутова хімія, продукти, тощо)
    double coefPrice;   //коефіцієнт удорожчення на первезення даного виду вантажу

}
