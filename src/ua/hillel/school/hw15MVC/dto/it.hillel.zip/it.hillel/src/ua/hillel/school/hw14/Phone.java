package ua.hillel.school.hw14;

abstract class Phone extends AbstractDevice {

    abstract void call(long numberPhone);
}
