package ua.codewars.wprime1;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;

public class WilsonPrime {
    public static boolean am_i_wilson(double n) {
        n = (long) n ;
        BigDecimal result = BigDecimal.ONE;
        BigInteger resultInt = BigInteger.ONE;
        long j = (long) (n-1);
        if (j <= 0) {
            return false;
        }
        for (int i = 1 ; i <= j ; i++) {
            result = BigDecimal.valueOf(j).multiply(result);
            resultInt = BigInteger.valueOf(j).multiply(resultInt);
        }
        BigDecimal upWilson = result.add(BigDecimal.valueOf(1));
        BigDecimal lowWilson = BigDecimal.valueOf((long)(n * n));

        BigInteger newWilson = upWilson.divide(lowWilson,512).toBigInteger();

        BigInteger upWilsonInt = resultInt.add(BigInteger.valueOf(1));
        BigInteger lowWilsonInt = BigInteger.valueOf((long)(n * n));
        BigInteger newWilsonInt = upWilsonInt.divide(lowWilsonInt);

        if (newWilson.equals(newWilsonInt)) {
            System.out.println("WilsonPrime");
            return true;
        }
        return false;
    }
}


