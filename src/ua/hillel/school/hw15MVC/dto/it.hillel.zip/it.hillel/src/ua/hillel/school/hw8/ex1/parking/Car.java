package ua.hillel.school.hw8.ex1.parking;

public class Car {

    int number;      //номер машини (державний)
    String brand;    //бренд авто
    String model;    //модель авто
    int year;        //рік випуску
    String vihBody;  //тип кузова (седан, хетчбек, купе, мікроавтобус, тощо)

}
