package ua.hillel.school.hw8.ex1.parking;

public class Client {

    int number;      //внутрішній номер клієнта
    String name;     //ім'я
    String secName;  //фамілія
    String phone;    //номер телефону
    int discount;    //знижка

}
