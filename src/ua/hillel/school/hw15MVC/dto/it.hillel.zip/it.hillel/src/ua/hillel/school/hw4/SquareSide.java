package ua.hillel.school.hw4;

public class SquareSide {

    int squareSide;
    int squareArea;
    int squarePerim;
    boolean sqComp;

}
