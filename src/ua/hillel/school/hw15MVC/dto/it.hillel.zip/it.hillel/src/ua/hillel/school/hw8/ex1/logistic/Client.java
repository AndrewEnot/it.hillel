package ua.hillel.school.hw8.ex1.logistic;

public class Client {

    int registerNumClient;       //реєстраційний номер (ЄДРПОУ-ДРФО)
    String nameCompany;          //назва компаніі клієнта
    String addressOffice;        //адреса клієнта
    String phoneContacts;        //телефоний номер офіса клієнта
    String emailContacts;        //електронна пошта
    String managerContacts;      //контактний номер відповідальної особи клієнта
    long ebanNumber;             //номер рахунку банківського
    int dealsNumber;             //кількість завершених угод
    int discount;                //знижка
    String branch;               //основний вид діяльності компанії клієнта

}
