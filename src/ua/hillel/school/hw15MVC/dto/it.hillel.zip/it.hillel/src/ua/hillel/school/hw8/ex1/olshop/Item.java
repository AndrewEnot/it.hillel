package ua.hillel.school.hw8.ex1.olshop;

public class Item {

    int number;            //код товару
    String name;           //назва товару
    double priceSell;      //ціна продажу
    double priceBuy;       //ціна закупівлі
    boolean presence;      //наявність на складі
    String description;    //опис
    String group;          //група товару (побутова хімія, іграшки, будівельні матеріали, тощо)

}
