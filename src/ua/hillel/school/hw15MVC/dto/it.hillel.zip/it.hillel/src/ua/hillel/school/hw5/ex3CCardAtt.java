package ua.hillel.school.hw5;

public class ex3CCardAtt {

    String cardNumber;
    String owner;
    String type;

}
