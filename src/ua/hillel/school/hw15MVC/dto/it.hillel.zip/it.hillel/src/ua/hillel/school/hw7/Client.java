package ua.hillel.school.hw7;

public class Client {

     String fullNameClient;
     int ageClient;
     double budgetClient;
     boolean creditClient;        //спроможність отримати кредит
     boolean wishCreditClient;    //бажання брати кредит

}
