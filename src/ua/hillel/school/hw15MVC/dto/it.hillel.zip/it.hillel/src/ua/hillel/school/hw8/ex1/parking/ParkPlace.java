package ua.hillel.school.hw8.ex1.parking;

public class ParkPlace {

    int number;       //внутрішній номер паркувального місця
    String type;      //тип паркувального місця (однарне, полуторне, подвійне)
    double costDay;   //вартість паркувального місця за один день
    double costHour;  //вартість паркувального місця за один час

}
