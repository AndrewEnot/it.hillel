package ua.exercism.ex8;

class MicroBlog {
    public String truncate(String input) {
        char[] inputArr = input.toCharArray();
        String inputNew = new String();
        if (inputArr.length <=4) {
            for (int i = 0; i < inputArr.length; i++) inputNew += String.valueOf(inputArr[i]);
            return inputNew;
        } else {
            for (int i = 0; i <= 4; i++) inputNew += String.valueOf(inputArr[i]);
            }
        return inputNew;
    }
}